const addition = (a,b)=>{
    return a+b;
}

module.exports = addition;
