const addition = require("./add");
const subtraction = require("./subtract");
const multiplication = require("./multiple");
const division = require("./divide");

console.log(addition(5, 5));
console.log(subtraction(5, 5));
console.log(multiplication(5, 5));
console.log(division(5, 5));
