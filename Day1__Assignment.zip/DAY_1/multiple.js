const multiplication = (a,b)=>{
    return a*b;
}

module.exports = multiplication;
