const subtraction = (a,b)=>{
    return a-b;
}

module.exports =  subtraction;
